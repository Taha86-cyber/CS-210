# CS210-Introduction-to-Data-Science
Group Project for CS210 in Spring 2022 at Sabancı University:  Predicting whether one has heart disease or not.
